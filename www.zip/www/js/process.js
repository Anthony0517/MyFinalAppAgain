
	var ass = (
		<div>
			<div className = "page1" data-page="page">
				<div className = "page-content">
					<div className= "navbar">
					<div className = "navbar-inner">
						<div className = "right">Coaching App
							<a className = "link" href = "#" onClick={Wala} data-panel = "left">
								<i className = "icon-bars icon"></i>
							</a>
						</div>
					</div>
				</div>
					<div className = "content-block-title" id="second"><center>Welcome to Coaching App!!!</center></div>
						<div className = "content-block-inner">
							<p> Coaching is unlocking a person’s potential to maximize their own performance. It is helping them to learn rather than teaching them.  </p></div>
							<div className = "content-block"></div>
								<div className = "content-block-title" id="second"><center>NAVIGATION</center></div>
									<div className = "list-block">
										<ul>
										<li>
											<a className = "item-link" href = "#" onClick={Statistics} data-view = "false" data-panel = "false" data-popup = "false"
											data-popover = "false" data-picker = "false" data-login-screen = "false" data-sortable = "false" data-page-name =
											"false" data-template = "false">
											<div className = "item-content">
												<div className = "item-inner">
													<div className = "item-title">Statistics</div>
												</div>
											</div>
										</a>
									</li>
									<li>
											<a className = "item-link" href = "#" onClick={Formation}  data-view = "false" data-panel = "false" data-popup = "false"
											data-popover = "false" data-picker = "false" data-login-screen = "false" data-sortable = "false" data-page-name =
											"false" data-template = "false">
											<div className = "item-content">
												<div className = "item-inner">
													<div className = "item-title">Formation</div>
													
												</div>
											</div>
										</a>
									</li>
									<li>
											<a className = "item-link" href = "#" onClick={Strategy}  data-view = "false" data-panel = "false" data-popup = "false"
											data-popover = "false" data-picker = "false" data-login-screen = "false" data-sortable = "false" data-page-name =
											"false" data-template = "false">
											<div className = "item-content">
												<div className = "item-inner">
													<div className = "item-title">Strategy</div>
													
												</div>
											</div>
										</a>
									</li>
									<li>
											<a className = "item-link" href = "#" onClick={Training} data-view = "false" data-panel = "false" data-popup = "false"
											data-popover = "false" data-picker = "false" data-login-screen = "false" data-sortable = "false" data-page-name =
											"false" data-template = "false">
											<div className = "item-content">
												<div className = "item-inner">
													<div className = "item-title">Training</div>
													
												</div>
											</div>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
		);
		ReactDOM.render(ass,document.getElementById('root'));


function Statistics() {
			var about = (
			<div>
				<div className= "navbar">
					<div className = "navbar-inner">
						<div className = "sliding left">
							<a className = "back link" href = "#" onClick={Back} data-panel = "left">
							<i className = "icon-back icon"></i>
							<span className>back</span>
							</a>
						</div>
					</div>
				</div>
			<div className="page page-on-center" id="stat">
				<div className="page-content">
					<div className="content-block-inner"> Records </div>
						<form className="list-block">
							<ul>
								<li>
									<div className="item-content">
										<div className="item-inner">
											<div className="label item-title">
												Win 
											 </div>
												<div className="item-input">
												<input type="number" id="a" placeholder="Win" /> 
												</div>
										</div>
									</div>
								</li>
								<li>
									<div className="item-content">
										<div className="item-inner">
											<div className="label item-title"> Draw </div>
											<div className=" item-input">
												<input type="number" id="b" placeholder="Draw" /> 
											</div>
										</div>
									</div>
								</li>
								<li>
									<div className="item-content">
										<div className="item-inner">
											<div className="label item-title"> Lose </div>
											<div className=" item-input">
												<input type="number" id="c" placeholder="Lose" /> 
											</div>
										</div>
									</div>
								</li>
								<li>
									<div className="item-content">
										<div className="item-inner">
											<div className="label item-title"> GoalScore </div>
											<div className=" item-input">
												<input type="number" id="d" placeholder="GS" /> 
											</div>
									</div>
								</div>
							</li>
							<li>
								<div className="item-content">
									<div className="item-inner">
										<div className="label item-title"> GoalConceded </div>
										<div className=" item-input">
											<input type="number" id="e" placeholder="GC" /> 
										</div>
									</div>
								</div>
							</li>
							</ul>
						</form>
						<div className="row">
							<div className="col-50">
								<a className="color-green button-fill button" href="#" onClick={Save} id="sv">
								Save
								</a>
									<div id="display_list"></div>
							</div>
							<div className="col-50">
								<a className="color-red button-fill button" href="#" onClick={Back} id="dlt">
								Cancel
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
	

			);
		ReactDOM.render(about,document.getElementById('root'));
		}

		function Save() {
			document.addEventListener('click' ,function (){
	let first = document.getElementById('a').value;
	let second = document.getElementById('b').value;
	let third = document.getElementById('c').value; 
	let fourth = document.getElementById('d').value;
	let fifth = document.getElementById('e').value;
	
	if (first && second && third && fourth && fifth!= 0){
		let testCount= 0;
		if(localStorage.getItem('test-count') == null){
			localStorage .setItem('test-count' ,0);
			testCount = 0;
		}
		else{
			testCount = localStorage.getItem('test-count');
		}
	
		localStorage.setItem('test-'+((testCount*1)+1),first);
		localStorage.setItem('test-'+((testCount*1)+2),second);
		localStorage.setItem('test-'+((testCount*1)+3),third);
		localStorage.setItem('test-'+((testCount*1)+4),fourth);
		localStorage.setItem('test-'+((testCount*1)+5),fifth);
		
		localStorage.setItem('test-count',((testCount*1)+5));
		console.log('proceed');
		

		let testCountNumber = (testCount*1)+5;
		let content = "";
		for(let a = 1; a<= testCountNumber; a++){
			content += "<li>" + localStorage.getItem('test-'+a)+"</li>";
		}
		document.getElementById('display_list').innerHTML = content;
		document.getElementById('a').value = "";
		document.getElementById('b').value = "";
		document.getElementById('c').value = "";
		document.getElementById('d').value = "";
		document.getElementById('e').value = "";		
	}
});

		//ReactDOM.render(click,document.getElementById('root'));	
		}

function Formation() {
	var pass = (
	<div>
			<div className= "navbar">
					<div className = "navbar-inner">
						<div className = "sliding left">
							<a className = "back link" href = "#" onClick={Back} data-panel = "left">
							<i className = "icon-back icon"></i>
							<span className>back</span>
							</a>
						</div>
					</div>
				</div>
		<div id="pic">
			<center>
				<img alt="" src="./img/a.png" size="100%" />
				<p> 4:4:2"Mutual Formation" </p>
				<img alt="" src="./img/b.png" size="100%" />
				<p> 4:1:3:2"Defensive and Attacking Formation" </p> 
				<img alt="" src="./img/c.png" size="100%" />
				<p> 4:3:1:2"Defensive Formation" </p>
				<img alt="" src="./img/d.png" size="100%" />
				<p> 4:2:3:1"Attacking Formation" </p>
				<img alt="" src="./img/e.png" size="100%" />
				<p> 4:3:2:1"Side Play Formation" </p>
				<img alt="" src="./img/f.png" size="100%" />
				<p> 4:4:1:1"Middle Attacking Formation" </p>
				<img alt="" src="./img/g.png" size="100%" />
				<p> 4:3:3"Best Possession Formation" </p>
				<img alt="" src="./img/h.png" size="100%" />
				<p> 4:1:2:3"Best Attacking Formation" </p>
				<img alt="" src="./img/i.png" size="100%" />
				<p> 5:3:2"Best Defensive Formation" </p>
				<img alt="" src="./img/j.png" size="100%" />
				<p> 5:2:1:2"Defensive Formation" </p>
			</center>
		</div>
	</div>
	);
	ReactDOM.render(pass,document.getElementById('root'));

}

function Strategy() {
	var passpass = (
		<div>
				<div className= "navbar">
					<div className = "navbar-inner">
						<div className = "sliding left">
							<a className = "back link" href = "#" onClick={Back} data-panel = "left">
							<i className = "icon-back icon"></i>
							<span className>back</span>
							</a>
						</div>
					</div>
				</div>
		<center>
			<div className="item-content" id="text">
				<div className="item-inner">
					<div className="label item-title"> Text Area </div>
						<form>
						<textarea id="tx" placeholder="You can write what ever you want here!!!"></textarea>
						</form>
							<div className="row">
								<div className="col-50">
									<a className="color-green button-fill button" href="#" onClick={sv} id="sv">
										Save
									</a>
									<div className="Note" id="notes"></div>
								</div>
								<div className="col-50">
									<a className="color-red button-fill button" href="#" onClick={Back} id="dlt">
								Cancel
								</a>
							</div>
						</div>
				</div>
			</div>
		</center>
		
		</div>


	);
	ReactDOM.render(passpass,document.getElementById('root'));
}

function Training() {
	
	var pass3 = (
		<div>
			<div className= "navbar">
					<div className = "navbar-inner">
						<div className = "sliding left">
							<a className = "back link" href = "#" onClick={Back} data-panel = "left">
							<i className = "icon-back icon"></i>
							<span className>back</span>
							</a>
						</div>
					</div>
				</div>
			<center>
				<input type="button" href="#" onClick={Para} id="btn" value="Pre-Season" />
				<input type="button" href="#" onClick={Para2} id="btn" value="Off-Season" />
			</center>
		</div>
	);
	ReactDOM.render(pass3,document.getElementById('root'));
}



function Para() {
	
	var pass5 = (
		<div>
		<div className= "navbar">
					<div className = "navbar-inner">
						<div className = "sliding left">
							<a className = "back link" href = "#" onClick={Training} data-panel = "left">
							<i className = "icon-back icon"></i>
							<span className>back</span>
							</a>
						</div>
					</div>
				</div>
		<div className="sulat">
			<p>The aim of pre-season training is to slowly build fitness levels and gain match practice. By the time you play the first game of season you should have played at least 5 friendlies, but over playing before the season starts has to be taken in to consideration.</p>
		</div>
		</div>
	);
	ReactDOM.render(pass5,document.getElementById('root'));
}

function Para2() {
	
	var pass6 = (
		<div>
		<div className= "navbar">
					<div className = "navbar-inner">
						<div className = "sliding left">
							<a className = "back link" href = "#" onClick={Training} data-panel = "left">
							<i className = "icon-back icon"></i>
							<span className>back</span>
							</a>
						</div>
					</div>
				</div>
		<p>It is the most important phase of any sport-specific conditioning plan. Not only will it help the athlete to recover physically and psychologically, it can be used to address some of the physical imbalances that are inherent with playing competitive sport.</p>
		</div>
	);
	ReactDOM.render(pass6,document.getElementById('root'));
}

function Wala() {
	alert("Ang simple pero maganda, parang SIYA!!!!!!");
	var pass4 = (
		<div>
<div className= "navbar">
					<div className = "navbar-inner">
						<div className = "sliding left">
							<a className = "back link" href = "#" onClick={Back} data-panel = "left">
							<i className = "icon-back icon"></i>
							<span className>back</span>
							</a>
						</div>
					</div>
				</div>
		</div>

	);
	ReactDOM.render(pass4,document.getElementById('root'));
}

function Back() {
var ass = (
		<div>
			<div className = "page1" data-page="page">
				<div className = "page-content">
					<div className= "navbar">
					<div className = "navbar-inner">
						<div className = "right">Coaching App
							<a className = "link" href = "#" onClick={Wala} data-panel = "left">
								<i className = "icon-bars icon"></i>
							</a>
						</div>
					</div>
				</div>
					<div className = "content-block-title" id="second"><center>Welcome to Coaching App!!!</center></div>
						<div className = "content-block-inner">
							<p> Coaching is unlocking a person’s potential to maximize their own performance. It is helping them to learn rather than teaching them.  </p></div>
							<div className = "content-block"></div>
								<div className = "content-block-title" id="second"><center>NAVIGATION</center></div>
									<div className = "list-block">
										<ul>
										<li>
											<a className = "item-link" href = "#" onClick={Statistics} data-view = "false" data-panel = "false" data-popup = "false"
											data-popover = "false" data-picker = "false" data-login-screen = "false" data-sortable = "false" data-page-name =
											"false" data-template = "false">
											<div className = "item-content">
												<div className = "item-inner">
													<div className = "item-title">Statistics</div>
												</div>
											</div>
										</a>
									</li>
									<li>
											<a className = "item-link" href = "#" onClick={Formation}  data-view = "false" data-panel = "false" data-popup = "false"
											data-popover = "false" data-picker = "false" data-login-screen = "false" data-sortable = "false" data-page-name =
											"false" data-template = "false">
											<div className = "item-content">
												<div className = "item-inner">
													<div className = "item-title">Formation</div>
													
												</div>
											</div>
										</a>
									</li>
									<li>
											<a className = "item-link" href = "#" onClick={Strategy}  data-view = "false" data-panel = "false" data-popup = "false"
											data-popover = "false" data-picker = "false" data-login-screen = "false" data-sortable = "false" data-page-name =
											"false" data-template = "false">
											<div className = "item-content">
												<div className = "item-inner">
													<div className = "item-title">Strategy</div>
													
												</div>
											</div>
										</a>
									</li>
									<li>
											<a className = "item-link" href = "#" onClick={Training} data-view = "false" data-panel = "false" data-popup = "false"
											data-popover = "false" data-picker = "false" data-login-screen = "false" data-sortable = "false" data-page-name =
											"false" data-template = "false">
											<div className = "item-content">
												<div className = "item-inner">
													<div className = "item-title">Training</div>
													
												</div>
											</div>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
		);
		ReactDOM.render(ass,document.getElementById('root'));
}
 function get_notes() {
        var notes = new Array;
        var notes_str = localStorage.getItem('note');
        if (notes_str !== null) {
            notes = JSON.parse(notes_str); 
        }
        return notes;
    }
     
    function sv() {
        var tx = document.getElementById('tx').value;
     
        var notes = get_notes();
        notes.push(tx);
        localStorage.setItem('note', JSON.stringify(notes));
     
        show();
     
        return false;
    }
     
     
    function show() {
        var notes = get_notes();
     
        var html = '<ul>';
        for(var i=0; i<notes.length; i++) {
            html += '<li>' + notes[i];
        };
        html;
     
        document.getElementById('notes').innerHTML = html;
     
    
    }
     
    //ReactDom.render(add,document.getElementById('root'));
    